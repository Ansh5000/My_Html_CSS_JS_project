
let price = document.getElementById("myprice").innerHTML
let name = document.getElementById("myname").innerHTML
let tbname = document.getElementById("tbname")
let tbprice = document.getElementById("tbprice")
let totalp = document.getElementById("total")
let quan = document.getElementById("quantity").innerHTML
tbprice.innerHTML ="₹"+ price
console.log(parseInt(quan)*parseInt(price))
totalp.innerHTML ="₹" + price*quan
tbname.innerHTML = name